"use client";

import { useState } from "react";
import type { FormParams } from "@/lib/types";

const CATEGORIES = [
  "Circular Economy / Reuse",
  "Marketplace (P2P)",
  "Fintech / Payments",
  "Health & Wellness",
  "Education (EdTech)",
  "Logistics & Delivery",
  "E-commerce",
  "Real Estate (PropTech)",
  "HR & Recruitment",
  "Food & Restaurant",
  "Travel & Transportation",
  "Social Network",
  "Productivity & Tools",
  "Entertainment & Media",
  "Agriculture (AgriTech)",
  "Legal & Compliance",
  "Sustainability / GreenTech",
  "Other",
];

const BUSINESS_MODELS = [
  "B2C — Direct to consumer",
  "B2B — Business to business",
  "B2B2C — Platform / aggregator",
  "Marketplace (takes commission)",
  "SaaS (subscription)",
  "Freemium",
  "On-demand service",
];

const REGIONS = [
  "Global (all markets)",
  "North America",
  "Latin America",
  "Europe",
  "Southeast Asia",
  "South Asia",
  "East Asia",
  "Middle East & North Africa",
  "Sub-Saharan Africa",
  "Oceania",
];

const EXAMPLES = [
  "Mobile app where neighbors can post, find and claim free items left on the street — furniture, electronics, clothes.",
  "AI legal assistant that drafts contracts and NDAs for freelancers and small businesses without a lawyer.",
  "Peer-to-peer marketplace to rent camping and outdoor gear from private owners instead of buying.",
];

interface Props {
  onSubmit: (params: FormParams) => void;
}

export default function ResearchForm({ onSubmit }: Props) {
  const [form, setForm] = useState<FormParams>({
    description: "",
    category: "",
    features: "",
    businessModel: "",
    targetRegions: "",
  });

  const set = (field: keyof FormParams) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((p) => ({ ...p, [field]: e.target.value }));

  const handleSubmit = () => {
    if (!form.description.trim()) return;
    onSubmit(form);
  };

  const fillExample = (text: string) => {
    setForm((p) => ({ ...p, description: text }));
  };

  const inputBase =
    "w-full bg-slate-900/80 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/20 transition-all";

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Description */}
      <div>
        <label className="flex items-center gap-1.5 text-sm font-medium text-slate-200 mb-2">
          App description
          <span className="text-blue-400 text-xs font-normal">(required)</span>
        </label>
        <textarea
          value={form.description}
          onChange={set("description")}
          placeholder="Describe your app idea in 2–4 sentences. What does it do? Who is it for? What problem does it solve?"
          className={`${inputBase} resize-none h-28`}
        />

        {/* Example chips */}
        <div className="flex flex-wrap gap-2 mt-2">
          {EXAMPLES.map((ex) => (
            <button
              key={ex}
              onClick={() => fillExample(ex)}
              className="text-xs text-slate-400 hover:text-blue-300 border border-slate-700/40 hover:border-blue-500/40 bg-slate-900/40 hover:bg-blue-500/5 px-2.5 py-1 rounded-lg transition-all text-left leading-snug"
            >
              ↗ {ex.slice(0, 55)}…
            </button>
          ))}
        </div>
      </div>

      {/* Category + Business Model */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Category <span className="text-slate-600">(optional)</span>
          </label>
          <select value={form.category} onChange={set("category")} className={inputBase}>
            <option value="">Auto-detect</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Business Model <span className="text-slate-600">(optional)</span>
          </label>
          <select value={form.businessModel} onChange={set("businessModel")} className={inputBase}>
            <option value="">Auto-detect</option>
            {BUSINESS_MODELS.map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Features */}
      <div>
        <label className="block text-xs font-medium text-slate-400 mb-1.5">
          Key features / value proposition <span className="text-slate-600">(optional)</span>
        </label>
        <input
          type="text"
          value={form.features}
          onChange={set("features")}
          placeholder="e.g. Real-time map of items, photo listings, in-app chat"
          className={inputBase}
        />
      </div>

      {/* Regions */}
      <div>
        <label className="block text-xs font-medium text-slate-400 mb-1.5">
          Focus regions <span className="text-slate-600">(optional — default: global)</span>
        </label>
        <select value={form.targetRegions} onChange={set("targetRegions")} className={inputBase}>
          {REGIONS.map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
      </div>

      {/* Submit */}
      <button
        onClick={handleSubmit}
        disabled={!form.description.trim()}
        className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-xl transition-all text-sm tracking-wide shadow-lg shadow-blue-900/30"
      >
        Analyze global market →
      </button>
    </div>
  );
}
