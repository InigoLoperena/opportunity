"use client";

import type { ResearchResult, MarketEntry, OpportunityEntry } from "@/lib/types";

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Convert ISO-3166 alpha-2 code to flag emoji (e.g. "US" → 🇺🇸) */
function flag(code: string): string {
  return code
    .toUpperCase()
    .replace(/./g, (c) => String.fromCodePoint(c.charCodeAt(0) + 127397));
}

const MATURITY = {
  mature:  { label: "Mature",  cls: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25" },
  growing: { label: "Growing", cls: "bg-blue-500/10   text-blue-400   border border-blue-500/25"    },
  nascent: { label: "Nascent", cls: "bg-purple-500/10 text-purple-400 border border-purple-500/25"  },
};

const CONFIDENCE = {
  high:   { label: "High confidence",   cls: "text-emerald-400" },
  medium: { label: "Medium confidence", cls: "text-amber-400"   },
  low:    { label: "Low confidence",    cls: "text-red-400"      },
};

// ── Sub-components ────────────────────────────────────────────────────────────

function MarketCard({ m }: { m: MarketEntry }) {
  const mat = MATURITY[m.market_maturity] ?? MATURITY.nascent;

  return (
    <div className="bg-slate-900/70 border border-slate-700/40 hover:border-slate-600/60 rounded-xl p-4 transition-colors animate-fade-up flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span className="text-xl leading-none select-none">{flag(m.country_code)}</span>
          <span className="font-semibold text-white text-sm">{m.country}</span>
        </div>
        <span className={`text-xs px-2 py-0.5 rounded-full shrink-0 ${mat.cls}`}>
          {mat.label}
        </span>
      </div>

      {/* Players */}
      {m.key_players?.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {m.key_players.map((p) => (
            <span
              key={p}
              className="text-xs bg-slate-800 text-slate-300 border border-slate-700/40 px-2 py-0.5 rounded-md"
            >
              {p}
            </span>
          ))}
        </div>
      )}

      {/* Notes */}
      {m.notes && (
        <p className="text-xs text-slate-400 leading-relaxed">{m.notes}</p>
      )}
    </div>
  );
}

function OpportunityCard({ o }: { o: OpportunityEntry }) {
  const score = Math.min(10, Math.max(1, Math.round(o.opportunity_score)));

  return (
    <div className="bg-slate-900/70 border border-amber-500/20 hover:border-amber-500/40 rounded-xl p-4 transition-colors animate-fade-up flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span className="text-xl leading-none select-none">{flag(o.country_code)}</span>
          <span className="font-semibold text-white text-sm">{o.country}</span>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <span className="text-amber-400 font-bold text-sm">{score}</span>
          <span className="text-slate-600 text-xs">/10</span>
        </div>
      </div>

      {/* Score bar */}
      <div className="flex gap-0.5">
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-colors ${
              i < score ? "bg-amber-400" : "bg-slate-700/60"
            }`}
          />
        ))}
      </div>

      {/* Reason */}
      <p className="text-xs text-amber-200/75 font-medium leading-relaxed">
        {o.opportunity_reason}
      </p>

      {/* Context + Challenges */}
      <div className="space-y-1.5">
        {o.market_context && (
          <p className="text-xs text-slate-400 leading-relaxed">
            <span className="text-slate-500 font-medium">Market: </span>
            {o.market_context}
          </p>
        )}
        {o.key_challenges && (
          <p className="text-xs text-slate-400 leading-relaxed">
            <span className="text-slate-500 font-medium">Challenges: </span>
            {o.key_challenges}
          </p>
        )}
      </div>
    </div>
  );
}

// ── Section header ─────────────────────────────────────────────────────────────

function SectionHeader({
  dot,
  title,
  count,
}: {
  dot: string;
  title: string;
  count: number;
}) {
  return (
    <div className="flex items-center gap-2.5 mb-4">
      <div className={`w-2 h-2 rounded-full ${dot}`} />
      <h2 className="text-xs font-semibold text-white uppercase tracking-widest">
        {title}
      </h2>
      <span className="text-xs text-slate-600">({count})</span>
    </div>
  );
}

// ── Main export ────────────────────────────────────────────────────────────────

interface Props {
  results: ResearchResult;
  onNewSearch: () => void;
}

export default function ResultsDisplay({ results, onNewSearch }: Props) {
  const conf = CONFIDENCE[results.confidence] ?? CONFIDENCE.medium;
  const sorted = [...(results.opportunity_markets ?? [])].sort(
    (a, b) => b.opportunity_score - a.opportunity_score
  );

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-up">

      {/* ── Summary card ── */}
      <div className="bg-slate-900/70 border border-slate-700/40 rounded-2xl p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="flex-1 min-w-0">
            {/* Category + confidence */}
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="text-xs font-mono bg-blue-500/10 text-blue-400 border border-blue-500/25 px-2.5 py-0.5 rounded-full">
                {results.identified_category}
              </span>
              <span className={`text-xs ${conf.cls}`}>· {conf.label}</span>
            </div>

            <p className="text-slate-300 text-sm leading-relaxed">
              {results.summary}
            </p>
          </div>

          <button
            onClick={onNewSearch}
            className="shrink-0 self-start text-xs text-slate-400 hover:text-white border border-slate-700/50 hover:border-slate-500 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap"
          >
            ← New search
          </button>
        </div>

        {/* Stats */}
        <div className="flex gap-8 mt-5 pt-5 border-t border-slate-700/30">
          <div>
            <div className="text-3xl font-bold text-emerald-400">
              {results.markets_with_solution?.length ?? 0}
            </div>
            <div className="text-xs text-slate-500 mt-0.5">Validated markets</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-amber-400">
              {results.opportunity_markets?.length ?? 0}
            </div>
            <div className="text-xs text-slate-500 mt-0.5">Opportunities found</div>
          </div>
        </div>
      </div>

      {/* ── Validated markets ── */}
      {results.markets_with_solution?.length > 0 && (
        <section>
          <SectionHeader
            dot="bg-emerald-400"
            title="Validated Markets"
            count={results.markets_with_solution.length}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {results.markets_with_solution.map((m) => (
              <MarketCard key={`${m.country_code}-${m.country}`} m={m} />
            ))}
          </div>
        </section>
      )}

      {/* ── Opportunity markets ── */}
      {sorted.length > 0 && (
        <section>
          <SectionHeader
            dot="bg-amber-400"
            title="Market Opportunities"
            count={sorted.length}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {sorted.map((o) => (
              <OpportunityCard key={`${o.country_code}-${o.country}`} o={o} />
            ))}
          </div>
        </section>
      )}

      {/* ── Global insights ── */}
      {results.global_insights && (
        <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-5">
          <p className="text-xs font-semibold text-blue-400 uppercase tracking-widest mb-2">
            Global Insights
          </p>
          <p className="text-sm text-slate-300 leading-relaxed">
            {results.global_insights}
          </p>
        </div>
      )}

      {/* ── Footer ── */}
      <div className="text-center pb-8">
        <button
          onClick={onNewSearch}
          className="text-sm text-slate-400 hover:text-white border border-slate-700/50 hover:border-slate-500 px-5 py-2.5 rounded-xl transition-colors"
        >
          Analyze another app →
        </button>
      </div>
    </div>
  );
}
