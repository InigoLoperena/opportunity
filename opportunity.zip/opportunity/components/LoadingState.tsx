"use client";

import { useEffect, useState } from "react";

const STEPS = [
  "Mapping global app ecosystems…",
  "Scanning North America & Europe…",
  "Analysing Latin America & Southeast Asia…",
  "Reviewing South Asia, MENA & Africa…",
  "Identifying market patterns…",
  "Evaluating opportunity gaps…",
  "Compiling intelligence report…",
];

export default function LoadingState() {
  const [step, setStep] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setStep((p) => (p < STEPS.length - 1 ? p + 1 : p));
        setVisible(true);
      }, 250);
    }, 2800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="max-w-sm mx-auto text-center py-20 flex flex-col items-center">
      {/* Radar graphic */}
      <div className="relative w-28 h-28 mb-8">
        {/* Static rings */}
        <div className="absolute inset-0 rounded-full border border-blue-500/15" />
        <div className="absolute inset-4 rounded-full border border-blue-500/20" />
        <div className="absolute inset-8 rounded-full border border-blue-500/30" />

        {/* Rotating sweep */}
        <div
          className="absolute inset-0 rounded-full animate-radar"
          style={{
            background:
              "conic-gradient(from 0deg, transparent 0deg, rgba(59,130,246,0.25) 55deg, transparent 55deg)",
          }}
        />

        {/* Centre dot */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse" />
        </div>

        {/* Blips */}
        <div
          className="absolute w-1.5 h-1.5 bg-emerald-400 rounded-full"
          style={{ top: "22%", left: "62%" }}
        />
        <div
          className="absolute w-1 h-1 bg-amber-400 rounded-full animate-blink"
          style={{ top: "60%", left: "28%", animationDelay: "0.4s" }}
        />
        <div
          className="absolute w-1 h-1 bg-blue-400 rounded-full animate-blink"
          style={{ top: "72%", left: "70%", animationDelay: "1.1s" }}
        />
      </div>

      <h3 className="text-base font-semibold text-white mb-2">
        Researching global markets
      </h3>

      {/* Rotating step message */}
      <p
        className="text-sm text-slate-400 h-5 transition-opacity duration-200"
        style={{ opacity: visible ? 1 : 0 }}
      >
        {STEPS[step]}
      </p>

      {/* Progress bar */}
      <div className="flex gap-1 mt-6">
        {STEPS.map((_, i) => (
          <div
            key={i}
            className="h-1 rounded-full transition-all duration-500"
            style={{
              width: i <= step ? "20px" : "6px",
              backgroundColor: i <= step ? "#3b82f6" : "#1e293b",
            }}
          />
        ))}
      </div>

      <p className="text-xs text-slate-600 mt-6">Typically takes 15–30 seconds</p>
    </div>
  );
}
