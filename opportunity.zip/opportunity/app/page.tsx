"use client";

import { useState } from "react";
import ResearchForm from "@/components/ResearchForm";
import ResultsDisplay from "@/components/ResultsDisplay";
import LoadingState from "@/components/LoadingState";
import type { ResearchResult, FormParams } from "@/lib/types";

type State = "idle" | "loading" | "results" | "error";

export default function HomePage() {
  const [state, setState] = useState<State>("idle");
  const [results, setResults] = useState<ResearchResult | null>(null);
  const [errorMsg, setErrorMsg] = useState("");

  // ── Research handler ──────────────────────────────────────────────────────
  const handleResearch = async (params: FormParams) => {
    setState("loading");
    setErrorMsg("");

    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error ?? "Research failed. Please try again.");
      }

      setResults(data as ResearchResult);
      setState("results");
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : "Something went wrong. Please try again."
      );
      setState("error");
    }
  };

  const reset = () => {
    setState("idle");
    setResults(null);
    setErrorMsg("");
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#070b14]">
      {/* Dot-grid background — only on idle so it doesn't fight results */}
      {state === "idle" && (
        <div className="fixed inset-0 bg-grid pointer-events-none opacity-50" />
      )}

      {/* ── Header ── */}
      <header className="relative border-b border-slate-800/60 px-6 py-4 z-10">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <button onClick={reset} className="flex items-center gap-2.5 group">
            <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg flex items-center justify-center text-xs shadow-lg shadow-blue-900/40">
              🌍
            </div>
            <div className="text-left">
              <span className="font-bold text-white text-sm tracking-tight group-hover:text-blue-300 transition-colors">
                Opportunity
              </span>
              <span className="hidden sm:inline text-slate-500 text-xs ml-2">
                Market Intelligence
              </span>
            </div>
          </button>

          {/* Status pill */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Powered by Claude
          </div>
        </div>
      </header>

      {/* ── Main ── */}
      <main className="relative px-6 py-12 z-0">

        {/* IDLE — hero + form */}
        {state === "idle" && (
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 text-xs bg-blue-500/10 border border-blue-500/20 text-blue-400 px-3 py-1.5 rounded-full mb-6 font-medium">
                <span>🔍</span>
                Global App Market Analysis
              </div>

              <h1 className="text-4xl sm:text-5xl font-bold text-white tracking-tight leading-tight mb-4">
                Where does your app<br />
                <span className="text-blue-400">already exist?</span>
              </h1>

              <p className="text-slate-400 text-base leading-relaxed max-w-xl mx-auto">
                Describe any app concept. Opportunity maps which countries have
                validated that solution — and where the market gap is yours to capture.
              </p>
            </div>

            <ResearchForm onSubmit={handleResearch} />

            {/* How it works */}
            <div className="mt-12 grid grid-cols-3 gap-4 text-center">
              {[
                { icon: "✍️", title: "Describe", desc: "Write a brief description of your app idea" },
                { icon: "🤖", title: "Analyze", desc: "Claude maps similar solutions worldwide" },
                { icon: "🎯", title: "Discover", desc: "See where it exists and where to launch" },
              ].map((step) => (
                <div key={step.title} className="space-y-1.5">
                  <div className="text-2xl">{step.icon}</div>
                  <div className="text-xs font-semibold text-slate-300">{step.title}</div>
                  <div className="text-xs text-slate-500 leading-snug">{step.desc}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LOADING */}
        {state === "loading" && <LoadingState />}

        {/* ERROR */}
        {state === "error" && (
          <div className="max-w-md mx-auto text-center py-20">
            <div className="text-4xl mb-4">⚠️</div>
            <h3 className="text-white font-semibold mb-2">Research failed</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">{errorMsg}</p>
            <button
              onClick={reset}
              className="bg-slate-800 hover:bg-slate-700 text-white text-sm px-5 py-2.5 rounded-xl transition-colors"
            >
              Try again
            </button>
          </div>
        )}

        {/* RESULTS */}
        {state === "results" && results && (
          <ResultsDisplay results={results} onNewSearch={reset} />
        )}
      </main>
    </div>
  );
}
