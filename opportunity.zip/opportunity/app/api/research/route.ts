import Anthropic from "@anthropic-ai/sdk";
import { NextRequest, NextResponse } from "next/server";

// Edge runtime: no cold starts, no 10-second timeout
export const runtime = "edge";
export const maxDuration = 120; // 2 min — enough for thorough research

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

// ── Prompt ────────────────────────────────────────────────────────────────────
// Key design: we ask for ONLY JSON so parsing is reliable.
// The model must name real apps/companies it actually knows about.
const SYSTEM_PROMPT = `You are Opportunity, an expert global market intelligence analyst
specializing in app ecosystem mapping across all world regions.

Your task: given an app concept, analyze the global market and return structured data on:
1. VALIDATED MARKETS — countries where a similar solution already operates successfully
2. OPPORTUNITY MARKETS — countries where this type of solution is absent or underdeveloped

Draw from your deep knowledge of:
- Global startup ecosystems, app stores, and venture capital databases
- Regional technology adoption rates and smartphone penetration
- Regulatory environments that affect app categories
- Economic and demographic factors per country
- Cultural nuances that drive or block adoption

CRITICAL OUTPUT RULES:
- Return ONLY a valid JSON object. No markdown, no code fences, no explanation.
- Use REAL app and company names you actually know.
- Cover all major world regions: North America, Europe, LATAM, SEA, South Asia,
  East Asia, MENA, Sub-Saharan Africa, Oceania.
- Opportunity scores: 1–10 where 10 = maximum untapped potential.
- country_code must be a valid ISO 3166-1 alpha-2 code (US, GB, AR, NG, IN, …).

JSON SCHEMA:
{
  "summary": "2–3 sentence executive summary of the global landscape",
  "identified_category": "The specific app category/vertical identified",
  "markets_with_solution": [
    {
      "country": "Full country name",
      "country_code": "XX",
      "market_maturity": "mature|growing|nascent",
      "key_players": ["Real App 1", "Real Company 2"],
      "notes": "Adoption level, notable context, why it counts as validated"
    }
  ],
  "opportunity_markets": [
    {
      "country": "Full country name",
      "country_code": "XX",
      "opportunity_score": 8,
      "opportunity_reason": "Specific reason why this is an untapped gap",
      "market_context": "Population, GDP level, internet/smartphone penetration, relevant factors",
      "key_challenges": "Concrete barriers: regulation, payments, cultural, competitive"
    }
  ],
  "global_insights": "2–3 sentences on observed patterns and strategic timing",
  "confidence": "high|medium|low"
}`;

// ── JSON extractor ─────────────────────────────────────────────────────────────
// Claude occasionally wraps output in markdown fences despite instructions.
// This handles that gracefully.
function extractJSON(text: string): object {
  const s = text.trim();

  // 1. Direct parse
  try { return JSON.parse(s); } catch {}

  // 2. Strip ```json ... ``` fences
  const fenced = s.match(/```(?:json)?\s*(\{[\s\S]*?\})\s*```/);
  if (fenced) { try { return JSON.parse(fenced[1]); } catch {} }

  // 3. Grab the largest {...} block
  const bare = s.match(/\{[\s\S]*\}/);
  if (bare) { try { return JSON.parse(bare[0]); } catch {} }

  throw new Error("Could not parse AI response. Please try again.");
}

// ── Route handler ─────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const { description, category, features, businessModel, targetRegions } =
      await req.json();

    if (!description?.trim()) {
      return NextResponse.json(
        { error: "App description is required." },
        { status: 400 }
      );
    }

    const userMessage = `Analyze this app concept globally:

App Description: ${description}
Category: ${category || "Auto-detect from description"}
Key Features / Value Proposition: ${features || "Auto-detect from description"}
Business Model: ${businessModel || "Not specified"}
Focus Regions: ${targetRegions || "All major global markets"}

Return which countries already have this solution running and which are untapped opportunities.`;

    // Build request — optionally enable live web search via env var
    // Default: Claude's training data (fast, works on Vercel Hobby)
    // ENABLE_WEB_SEARCH=true → live search (needs Vercel Pro or self-hosted)
    const useWebSearch = process.env.ENABLE_WEB_SEARCH === "true";

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const requestParams: any = {
      model: "claude-sonnet-4-6",
      max_tokens: 4000,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }],
    };

    if (useWebSearch) {
      requestParams.tools = [{ type: "web_search_20250305", name: "web_search" }];
    }

    const response = await client.messages.create(requestParams);

    // Extract text blocks (might also contain tool_use blocks if web search is on)
    const textBlocks = response.content.filter(
      (b): b is Anthropic.TextBlock => b.type === "text"
    );
    const fullText = textBlocks.map((b) => b.text).join("");

    if (!fullText) {
      return NextResponse.json(
        { error: "No research data returned. Please try again." },
        { status: 500 }
      );
    }

    const data = extractJSON(fullText);
    return NextResponse.json(data);

  } catch (err) {
    console.error("[/api/research] Error:", err);
    const message =
      err instanceof Error ? err.message : "Research failed. Please try again.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
