export interface MarketEntry {
  country: string;
  country_code: string;
  market_maturity: "mature" | "growing" | "nascent";
  key_players: string[];
  notes: string;
}

export interface OpportunityEntry {
  country: string;
  country_code: string;
  opportunity_score: number;
  opportunity_reason: string;
  market_context: string;
  key_challenges: string;
}

export interface ResearchResult {
  summary: string;
  identified_category: string;
  markets_with_solution: MarketEntry[];
  opportunity_markets: OpportunityEntry[];
  global_insights: string;
  confidence: "high" | "medium" | "low";
}

export interface FormParams {
  description: string;
  category: string;
  features: string;
  businessModel: string;
  targetRegions: string;
}
